package com.visualpathit.account.service;

public interface ProducerService {

    public String  produceMessage(String message);
}
